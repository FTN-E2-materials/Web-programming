package beans.webshop;

public class ProductToAdd {
	public String id;
	public int count;
}
