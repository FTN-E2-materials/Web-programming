package beans.webshop.kendo;

public class ProductToAdd {
	public String id;
	public int count;
}
