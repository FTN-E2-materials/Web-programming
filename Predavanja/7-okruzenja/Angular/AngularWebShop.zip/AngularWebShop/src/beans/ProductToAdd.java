package beans;

public class ProductToAdd {
	public String id;
	public int count;
}
