webShop.directive('addToCart', function() {
        return {
            restrict: 'E',
            templateUrl: 'directives/addToCart.html'
        };
});