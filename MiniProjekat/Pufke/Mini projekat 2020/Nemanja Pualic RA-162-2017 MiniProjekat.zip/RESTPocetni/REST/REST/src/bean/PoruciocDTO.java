package bean;

public class PoruciocDTO {
	public String statusIzrade; 
	public String brojIzrade;
	public String imeNarucioca;
	public String brojTelefona;
	public String nazivFoldera;
	public String formatFotografija;
	public String cenaIzrade;
}
